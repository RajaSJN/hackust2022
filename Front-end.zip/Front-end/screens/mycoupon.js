import React, { useState, useEffect } from "react";
import { View, Text, Button, StyleSheet, TouchableOpacity, Image, Alert } from 'react-native';
import { useFonts, Inter_900Black, Nunito_Sans } from '@expo-google-fonts/inter';


// let [fontsLoaded] = useFonts({
//     Nunito_Sans,
// });

const myCoupon = ({ navigation }) => {



    return (
        < View style={styles.container} >

            <Image
                source={require('../assets/icons/suslogo.png')}
                resizeMode='contain'
                style={{
                    width: 800,

                }} />
            <TouchableOpacity style={styles.box}>
                <Text style={styles.txt}>
                    You have 15 % gift card for evolution
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.box}>
                <Text style={styles.txt}>
                    You have 20 % gift card for Clinique
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.box}>
                <Text style={styles.txt}>
                    You have 10 % gift card for Samsung
                </Text>
            </TouchableOpacity>


        </View >
    );
};


const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#ecbd2a',
    },
    txt: {
        fontSize: 50,
        fontFamily: 'Nunito_sans', fontSize: 15,
    },
    title: {
        fontSize: 20,
        marginVertical: 10,
    },
    Description: {
        fontSize: 15,
        marginHorizontal: 20,

        textAlign: "center",
    },
    box: {
        marginVertical: 20,
        width: 300,
        borderRadius: 80,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        height: 70,

    }

});

export default myCoupon;



    // const [name, setName] = useState();
    // const vision = require('@google-cloud/vision');

    // // Creates a client
    // const client = new vision.ImageAnnotatorClient();

    // /**
    //  * TODO(developer): Uncomment the following line before running the sample.
    //  */
    // const fileName = 'image.jpeg';



    // // Performs logo detection on the local file
    // const [result] = async () => await client.logoDetection(fileName);
    // const logos = result.logoAnnotations;
    // console.log('Logos:');
    // logos.forEach(logo => console.log(logo));
    // setName(logos);



    // //Javs
    // function postData(input) {
    //     $.ajax({
    //         type: "POST",
    //         url: "/sensor.py",
    //         data: { param: input },
    //         success: callbackFunc
    //     });
    // }

    // function callbackFunc(response) {
    //     // do something with the response
    //     console.log(response);
    //     setName(response);
    // }

    // postData('data to process');



    // const { spawn } = require('child_process');
    // const temperatures = []; // Store readings

    // const sensor = spawn('python', ['sensor.py']);
    // sensor.stdout.on('data', function (data) {

    //     // convert Buffer object to Float
    //     temperatures.push(parseFloat(data));
    //     console.log(temperatures);
    //     setName(temperatures);
    // });