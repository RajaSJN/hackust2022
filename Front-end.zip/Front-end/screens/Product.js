import React, { useState, useEffect } from "react";
import { View, Text, Button, StyleSheet, TouchableOpacity, Image, Alert } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Camera } from 'expo-camera';
import * as google from '@google-cloud/functions-framework';
import axios from 'axios';



// const functions = require('@google-cloud/functions-framework');
// const escapeHtml = require('escape-html');
// Download the file  



// HTTP Cloud Function.
// functions.http('https://us-central1-sustoken.cloudfunctions.net/functions-hello-world', (req, res) => {
//     res.send(Hello ${ escapeHtml(req.query.name || req.body.name || 'World')
// }!);
// });



const Product = ({ navigation }) => {
    let showQR = false;
    let showOnce = false;

    const [text, setText] = useState();
    const [title, setTitle] = useState();
    const getText = () => {
        baseURL = 'https://asia-east2-sustoken.cloudfunctions.net/company-summary';
        axios.get(baseURL)
            .then(async function (response) {
                setText(response.data);
                console.log(text);
            })
            .catch((error) => console.log(error));;
        // fetch('https://us-central1-sustoken.cloudfunctions.net/functions-hello-world', { method: 'GET' }).then((response) => response.json())
        //     .then((responseJson) => {
        //         responseJson = JSON.stringify(responseJson);
        //         console.log(responseJson);
        //         // setText(responseJson);

        //     })
        //     .catch((error) => {
        //         console.error(error)
        //     });
    }


    const getTitle = () => {
        baseURL = 'https://us-central1-sustoken.cloudfunctions.net/functions-hello-world';
        axios.get(baseURL)
            .then(async function (response) {
                setTitle(response.data);
                console.log(title);
            })
            .catch((error) => console.log(error));;

    }



    const [count, setCount] = useState(0);
    useEffect(() => {
        // increment the count by 1
        const countTimer = setInterval(() => {
            if (!showOnce) {
                getText();
                getTitle();
                showOnce = true;
            }
            if (!showQR) {

                if (count < 20) {
                    setCount((prevCount) => prevCount + 1);
                }// every 1000 milliseconds
                else {
                    showQR = true;
                    Alert.alert('CONGRATULATIONS', ' redeem your qr giftcode now', [
                        { text: 'Reedem', onPress: () => navigation.navigate("Redeem") },
                    ]);
                }
            }
        }, 1000);
        // and clear this timer when the component is unmounted
        return function cleanup() {
            clearInterval(countTimer);
        };
    });


    return (
        < View style={styles.container} >
            <Text style={styles.title}>
                Product Name:
            </Text>
            <Text style={styles.title} >
                {title}
            </Text>
            <Text style={styles.title}>
                Product Description:
            </Text>
            <Text style={styles.Description}>
                {text}
            </Text>

            <Text style={styles.txt}>{count}</Text>
        </View >
    );
};


const styles = StyleSheet.create({

    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    txt: {
        fontSize: 50,
    },
    title: {
        fontSize: 20,
        marginVertical: 10,
    },
    Description: {
        fontSize: 15,
        marginHorizontal: 50,

        textAlign: "center",
    }

});

export default Product;



    // const [name, setName] = useState();
    // const vision = require('@google-cloud/vision');

    // // Creates a client
    // const client = new vision.ImageAnnotatorClient();

    // /**
    //  * TODO(developer): Uncomment the following line before running the sample.
    //  */
    // const fileName = 'image.jpeg';



    // // Performs logo detection on the local file
    // const [result] = async () => await client.logoDetection(fileName);
    // const logos = result.logoAnnotations;
    // console.log('Logos:');
    // logos.forEach(logo => console.log(logo));
    // setName(logos);



    // //Javs
    // function postData(input) {
    //     $.ajax({
    //         type: "POST",
    //         url: "/sensor.py",
    //         data: { param: input },
    //         success: callbackFunc
    //     });
    // }

    // function callbackFunc(response) {
    //     // do something with the response
    //     console.log(response);
    //     setName(response);
    // }

    // postData('data to process');



    // const { spawn } = require('child_process');
    // const temperatures = []; // Store readings

    // const sensor = spawn('python', ['sensor.py']);
    // sensor.stdout.on('data', function (data) {

    //     // convert Buffer object to Float
    //     temperatures.push(parseFloat(data));
    //     console.log(temperatures);
    //     setName(temperatures);
    // });