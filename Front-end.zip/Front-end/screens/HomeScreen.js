import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet, Pressable, Image, Platform, Alert, TouchableOpacity, Touchable } from 'react-native';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import { LinearGradient } from 'expo-linear-gradient';
import * as ImagePicker from 'expo-image-picker';
import CameraScreen from './CameraScreen';
import TestScreen from './Product';
import axios from 'axios';


import { Camera } from 'expo-camera';
import * as firebase from 'firebase/app';
// import 'firebase/storage';
import { getStorage, ref, uploadBytes } from "firebase/storage";
import { NavigationContainer } from '@react-navigation/native';





const HomeScreen = ({ navigation, route }) => {


    const [image, setImage] = useState(null);
    const [text, setText] = useState();
    baseURL = 'https://us-central1-sustoken.cloudfunctions.net/functions-hello-world';
    const getText = () => {
        axios.get(baseURL)
            .then(async function (response) {
                setText(response.data);
                console.log(text);
            })
            .catch((error) => console.log(error));;

    }

    const pickImage = async () => {

        // No permissions request is necessary for launching the image library
        let result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.All,
            allowsEditing: true,
            aspect: [4, 4],
            quality: 1,
        });


        console.log(result);

        if (!result.cancelled) {
            setImage(result.uri, "my-image");

            UploadImage(result.uri, "my-image");
            try {
                getText();
                Alert.alert('Product Name: ', ' Evolve Organic Beauty \r\n\ \r\n\ Do you want to see the ESG rating', [
                    {
                        text: 'Cancel',
                        onPress: () => console.log('Cancel Pressed'),
                        style: 'cancel',
                    },

                    { text: 'OK', onPress: () => navigation.navigate("Product") },
                ]);

            }
            catch (err) {
                Alert.alert("error");
            }
        }
    };


    const UploadImage = async (uri, imageName) => {

        // No permissions request is necessary for launching the image library
        const response = await fetch(uri);
        const blob = await response.blob();
        const storage = getStorage();

        // for now one image only keep changing 
        const storageRef = ref(storage, 'some-child.jpg');


        // 'file' comes from the Blob or File API
        uploadBytes(storageRef, blob).then((snapshot) => {
            console.log('Uploaded a blob or file!');
        });
        // var reference = firebase.storage().reference().child("images/" + imageName);
        // return reference.put(blob);

    };

    // const hideTabBar = () => {
    //     navigation.setOptions({
    //         tabBarVisible: false,
    //     });
    // };
    // const showTabBar = () => {
    //     navigation.setOptions({
    //         tabBarVisible: true,
    //     });
    // };




    return (
        <View style={styles.container} className="container" >
            <LinearGradient
                // colors={['rgba(0, 0, 0,0.8)', 'transparent']}
                colors={['rgb(236, 189, 42)', '#fbf9ea', '#ecbd2a']}
                start={[0.1, 0.1]}
                end={[0.8, 0.8]}
                style={styles.background}
            >

                <Image
                    source={require('../assets/icons/suslogo.png')}
                    resizeMode='contain'
                    style={{
                        width: 800,

                    }} />


                {image && <Image source={{ uri: image }} style={{ width: 200, height: 200, marginVertical: 50, borderRadius: 10 }} />}
                <TouchableOpacity style={styles.btn} onPress={pickImage} >
                    <Text style={{ color: '#fff' }}>Pick From Gallery</Text>
                </TouchableOpacity>


                <TouchableOpacity onPress={() => navigation.navigate("CameraScreen")}
                    style={styles.btn}>
                    <Text style={{ color: '#fff' }}>Open Camera</Text>
                </TouchableOpacity>

                {/* <TouchableOpacity
                    onPress={__startCamera}
                    style={{
                        width: 130,
                        borderRadius: 4,
                        backgroundColor: '#14274e',
                        flexDirection: 'row',
                        justifyContent: 'center',
                        alignItems: 'center',
                        height: 40
                    }}
                >
                    <Text
                        style={{
                            color: '#fff',
                            fontWeight: 'bold',
                            textAlign: 'center'
                        }}
                    >
                        Take picture
                    </Text>
                </TouchableOpacity> */}


            </LinearGradient>
        </View>


    );
};


const styles = StyleSheet.create({
    container: {

        flex: 1,
        // backgroundColor: '#c7eff3',
        backgroundColor: '#ecbd2a',
        alignItems: 'center',
        justifyContent: 'center',
    },
    background: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        height: '100%',
    },

    btn: {
        marginVertical: 20,
        width: 130,
        borderRadius: 10,
        backgroundColor: '#162535',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        height: 80,

    }


});


export default HomeScreen;


// createBucket().catch(console.error);