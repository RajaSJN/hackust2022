import React, { useState, useEffect } from "react";
import { View, Text, Button, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Camera } from 'expo-camera';
import * as google from '@google-cloud/functions-framework';
import axios from 'axios';
import { HORIZONTAL } from "react-native/Libraries/Components/ScrollView/ScrollViewContext";



// const functions = require('@google-cloud/functions-framework');
// const escapeHtml = require('escape-html');
// Download the file  



// HTTP Cloud Function.
// functions.http('https://us-central1-sustoken.cloudfunctions.net/functions-hello-world', (req, res) => {
//     res.send(Hello ${ escapeHtml(req.query.name || req.body.name || 'World')
// }!);
// })



const Redeem = () => {

    let showOnce = false;
    const [text, setText] = useState();
    const [title, setTitle] = useState();
    const getText = () => {
        baseURL = 'https://asia-east2-sustoken.cloudfunctions.net/company-summary';
        axios.get(baseURL)
            .then(async function (response) {
                setText(response.data);
                console.log(text);
            })
            .catch((error) => console.log(error));;
        // fetch('https://us-central1-sustoken.cloudfunctions.net/functions-hello-world', { method: 'GET' }).then((response) => response.json())
        //     .then((responseJson) => {
        //         responseJson = JSON.stringify(responseJson);
        //         console.log(responseJson);
        //         // setText(responseJson);

        //     })
        //     .catch((error) => {
        //         console.error(error)
        //     });
    }

    const getTitle = () => {
        baseURL = 'https://us-central1-sustoken.cloudfunctions.net/functions-hello-world';
        axios.get(baseURL)
            .then(async function (response) {
                setTitle(response.data);
                console.log(title);
            })
            .catch((error) => console.log(error));;

    }


    // componentDidMount = () => {
    //     this.getText()
    // }
    if (!showOnce) {
        getText();
        getTitle();
        showOnce = true;
    }

    return (

        < View style={styles.container} >
            <Text style={styles.title} >
                Product Name:
            </Text>
            <Text style={styles.title} >
                {title}
            </Text>
            <Text style={styles.title}>
                Product Description:
            </Text>
            <Text style={styles.Description}>
                {text}
            </Text>
            {/* <Button title="test" onPress={getText} /> */}

            <Image
                source={require('../assets/icons/qr1.png')}
                resizeMode='contain'
                style={{

                    left: 8,
                    width: 200,
                    height: 200,
                    marginVertical: 30,
                }} />
            <Text style={styles.Description}>
                coupon expires in 7 days
            </Text>
        </View >
    );
};


const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    txt: {
        fontSize: 50,
    },
    title: {
        fontSize: 20,
        marginVertical: 10,
    },
    Description: {
        fontSize: 15,
        marginHorizontal: 50,

        textAlign: "center",
    }

});

export default Redeem;



    // const [name, setName] = useState();
    // const vision = require('@google-cloud/vision');

    // // Creates a client
    // const client = new vision.ImageAnnotatorClient();

    // /**
    //  * TODO(developer): Uncomment the following line before running the sample.
    //  */
    // const fileName = 'image.jpeg';



    // // Performs logo detection on the local file
    // const [result] = async () => await client.logoDetection(fileName);
    // const logos = result.logoAnnotations;
    // console.log('Logos:');
    // logos.forEach(logo => console.log(logo));
    // setName(logos);



    // //Javs
    // function postData(input) {
    //     $.ajax({
    //         type: "POST",
    //         url: "/sensor.py",
    //         data: { param: input },
    //         success: callbackFunc
    //     });
    // }

    // function callbackFunc(response) {
    //     // do something with the response
    //     console.log(response);
    //     setName(response);
    // }

    // postData('data to process');



    // const { spawn } = require('child_process');
    // const temperatures = []; // Store readings

    // const sensor = spawn('python', ['sensor.py']);
    // sensor.stdout.on('data', function (data) {

    //     // convert Buffer object to Float
    //     temperatures.push(parseFloat(data));
    //     console.log(temperatures);
    //     setName(temperatures);
    // });