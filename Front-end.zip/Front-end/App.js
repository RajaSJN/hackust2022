
import * as React from 'react';
import { View, Text, Button, StyleSheet, Pressable, Image, Platform, Alert, TouchableOpacity, Touchable } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";



import HomeScreen from './screens/HomeScreen';
import Product from './screens/Product';
import Redeem from './screens/Reedem';
import CameraScreen from './screens/CameraScreen';

import { createStackNavigator } from '@react-navigation/stack';
import myCoupon from './screens/mycoupon';
// import { HomeScreenNavigator } from './navigation/customNavigation';


const Tab = createBottomTabNavigator();




function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerTransparent: true,
        tabBarShowLabel: false,
        tabBarStyle: {
          position: 'absolute',
          bottom: 50,
          left: 20,
          right: 20,
          backgroundColor: 'rgba(255, 255, 255, 1)',
          borderRadius: 35,
          height: 80,
        }
      }}
    >

      <Tab.Screen name=" " component={HomeScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            < View >
              <Image
                source={require('./assets/icons/home.png')}
                resizeMode='contain'
                style={{
                  left: 6,
                  width: 25,
                  height: 25,
                  tintColor: focused ? '#e4bf51' : '#7489c4',
                }} />
              <Text
                style={{ color: focused ? '#999' : '#7489c4' }}
              > Home </Text>
            </View>
          ),
        }} />
      < Tab.Screen name="Coupon" component={myCoupon}

        options={{
          tabBarIcon: ({ focused }) => (
            < View >
              <Image
                source={require('./assets/icons/coupon.png')}
                resizeMode='contain'
                style={{
                  left: 15,
                  width: 30,
                  height: 25,
                  tintColor: focused ? '#e4bf51' : '#7489c4',
                }} />
              <Text
                style={{ color: focused ? '#999' : '#7489c4' }}
              > My Coupon </Text>
            </View>
          ),
        }}
      />
    </Tab.Navigator >

  );
}


// const style = StyleSheet.create({
//     shadow: {
//         shadowColor: ' #7F5DF0',
//         shadowOffset: {
//             width: 0,
//             height: 10,
//         },
//         shadowOpacity: 0.25,
//         shadowRadius: 3.5,
//         elevation: 5,
//     }
// });




const Stack = createStackNavigator();

export default function App() {

  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyBuG3ba837x2P3KPvcy_hsu8ZKLaG-AXn4",
    authDomain: "sustoken.firebaseapp.com",
    projectId: "sustoken",
    storageBucket: "sustoken.appspot.com",
    messagingSenderId: "856929242603",
    appId: "1:856929242603:web:718c7389cf78996e2c9dae",
    measurementId: "G-08DSZ7FLE3"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  // const analytics = getAnalytics(app);

  // var admin = require("firebase-admin");

  // var serviceAccount = require("Fortino2.json");

  // admin.initializeApp({
  //   credential: admin.credential.cert(serviceAccount)
  // });


  // Imports the Google Cloud client library
  // const { Storage } = require('@google-cloud/storage');

  // For more information on ways to initialize Storage, please see
  // https://googleapis.dev/nodejs/storage/latest/Storage.html

  // Creates a client using Application Default Credentials

  // Creates a client from a Google service account key
  // const storage = new Storage({ keyFilename: 'Fortino.json' });

  /**
   * TODO(developer): Uncomment these variables before running the sample.
   */
  // The ID of your GCS bucket
  // const bucketName = 'your-unique-bucket-name';

  // async function createBucket() {
  //   // Creates the new bucket
  //   await storage.createBucket(bucketName);
  //   console.log(`Bucket ${bucketName} created.`);
  // }
  // The ID of your GCS bucket
  // const bucketName = 'gs://hackust';

  // The path to your file to upload
  // const filePath = 'path/to/your/file';

  // The new ID for your GCS file
  // const destFileName = 'your-new-file-name';
  // async function uploadFile() {
  //   await storage.bucket(bucketName).upload(filePath, {
  //     destination: destFileName,
  //   });

  //   console.log(`${filePath} uploaded to ${bucketName}`);
  // }

  // uploadFile().catch(console.error);


  // initializeApp(firebaseConfig);

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerTransparent: true, headerShowLabel: false }}>
        <Stack.Screen name=" " component={Tabs} />
        <Stack.Screen name="CameraScreen" component={CameraScreen} />
        <Stack.Screen name="Product" component={Product} />
        <Stack.Screen name="Redeem" component={Redeem} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
